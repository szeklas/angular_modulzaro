import { Component } from '@angular/core';

@Component({
  selector: 'app-hosegriado',
  templateUrl: './hosegriado.component.html',
  styleUrl: './hosegriado.component.css'
})
export class HosegriadoComponent {

  elsoNapErtek!:number
  masodikNapErtek!:number
  harmadikNapErtek!:number

  visszajelzoUzenet!:string
  eredmenyek:string[]=[]

  
  aktualisRiadoSzint(){

    if(this.elsoNapErtek==null || this.masodikNapErtek==null || this.harmadikNapErtek==null){
      alert("Üres mező!")
    }
    
    if(this.elsoNapErtek || this.masodikNapErtek || this.harmadikNapErtek >24){
      this.visszajelzoUzenet=`${this.elsoNapErtek},${this.masodikNapErtek} és ${this.harmadikNapErtek} esetén 1.szintű hőségriadó volt elrendelve`
    }
    if(this.elsoNapErtek && this.masodikNapErtek && this.harmadikNapErtek >25){
      this.visszajelzoUzenet=`${this.elsoNapErtek},${this.masodikNapErtek} és ${this.harmadikNapErtek} esetén 2.szintű hőségriadó volt elrendelve`
    }
    if(this.elsoNapErtek && this.masodikNapErtek && this.harmadikNapErtek >26){
      this.visszajelzoUzenet=`${this.elsoNapErtek},${this.masodikNapErtek} és ${this.harmadikNapErtek} esetén 3.szintű hőségriadó volt elrendelve`
    }


    this.eredmenyek.push(this.visszajelzoUzenet)
  }
}


